#!/bin/sh

Cy='\033[34;1m' #biru            
i='\033[32;1m' #ijo    
pur='\033[35;1m' #purple
e='\033[36;1m' #cyan 
me='\033[31;1m' #merah
pu='\033[37;1m' #putih
ku='\033[33;1m' #kuning
echo $me"                               .,od88888888888bo,."
echo $me"                           .d88888888888888888888888b."
echo $me"                        .d88888888888888888888888888888b."
echo $me"                      .d888888888888888888888888888888888b."
echo $me"                    .d8888888888888888888888888888888888888b."
echo $me"                   d88888888888888888888888888888888888888888b"
echo $me"                  d8888888888888888888888888888888888888888888b"
echo $me"                 d888888888888888888888888888888888888888888888"
echo $me"                 8888888888888888888888888888888888888888888888"
echo $me"                 8888888888888888888888888888888888888888888888"
echo $me"                 8888888888888888888888888888888888888888888888"
echo $me"                 Y88888888888888888888888888888888888888888888P"
echo $me"                 *88888888888*   *Y8888888888P*    *Y888888888*"
echo $me"                  88888888P        Y88888888P        Y88888888"
echo $me"                  Y8888888          ]888888P          8888888P"
echo $me"                   Y888888          d888888b          888888P"
echo $me"                    Y88888b        d88888888b        d88888P"
echo $me"                     Y888888b.   .d88888888888b.   .d888888"
echo $me"                      Y8888888888888888P Y8888888888888888"
echo $me"                       888888888888888P   Y88888888888888"
echo $me"                       *8888888888888[     ]888888888888*"
echo $me"                          *Y888888888888888888888888P"
echo $me"                               *Y88888888888888P"
echo $me"                            888b  Y8888888888P  d888"
echo $me"                             888b              d888"
echo $me"                             Y888bo.        .od888P"
echo $me"                              Y888888888888888888P"
echo $me"                               Y88888888888888P"
echo $me"                                 *Y8888888888P"
echo $me"         d8888bo.                  *Y888888P*                  .od888b"
echo $me"        888888888bo.                  ****                  .od8888888"
echo $me"        *88888888888b.                                   .od888888888["
echo $me"        d8888888888888bo.                              .od888888888888"
echo $me"      d88888888888888888888bo.                     .od8888888888888888b"
echo $me"      ]888888888888888888888888bo.            .od8888888888888888888888b"=
echo $me"      888888888P* *Y888888888888888bo.     .od88888888888888P* * Y888888P="
echo $me"       Y8888P*           *Y888888888888bd888888888888P              Y8P"
echo $me"         **                   *Y88888888888888888*"
echo $me"                                .od8888888888bo."
echo $me"                            .od888888888888888888bo."
echo $me"                        .od8888888888P*  *Y8888888888bo."
echo $me"                     .od8888888888P*        *Y8888888888bo."
echo $me"                 .od88888888888P*              *Y88888888888bo."
echo $me"       .od888888888888888888P*                    *Y8888888888888888bo."
echo $me"      Y8888888888888888888P*                         *Y8888888888888888b="
echo $me"      888888888888888888P*                            *Y8888888888888888="
echo $me"       *Y888888888888888       Bloody Gaming 71         *Y88888888888888P="
echo $me"            **Y8888888P                                  *Y888888P"
echo $me"               &Y8888P                                     Y888P"
echo $me"                  **                                        **"


echo $pur"________________________________________________"
echo $pur"|          INDONYMOUS HACKING TOOLS            |"
echo $pur"|         Tools BY:Rieeef / Mr.Cybers.         |"
echo $pur"|       Channel Youtube:Bloody Gaming71        |"
echo $cy"|           Facebook:Mohammad Kelvin           |"
echo $cy"|             instagram:Mr.Cyber               |"
echo $ku"|      Jangan Lupa Subscribe Channel aing      |"
echo $cy"################################################"



echo $me" 1."$e"HAMMERING DDOS           "
echo $me" 2."$e"PENETRATION Test R_HAWK  "
echo $me" 3."$e"LACAK VIA WEB PHISING     "
echo $me" 4."$e"TOOLS HACK FB LENGKAP        "
echo $me" 5."$e"SQLMap                   "
echo $me" 6."$e"HYDRA PENETRATION TEST   "
echo $me" 7."$e"BUAT SCRIPT DEFACE            "
echo $me" 8."$e"PROFILE GUARD FACEBOOK   "
echo $me" 9."$e"FACEBOOK REPORT AUTO BAN "
echo $me"10."$e"INSTAGRAM (FOLLOWING BELOM JADI)      "
echo $me"11."$e"VIRTEXT GANAS!           "
echo $me"12."$e"HACK WIFI (ROOT)      "
echo $me"13."$e"SPAM CALL WORK        "
echo $me"14."$e"FACEBOOK shellphis    (PHISING)   "
echo $me"15."$e"FACEBOOK Blackeye     (PHISING)   "
echo $me"16."$e"FACEBOOK SOCIALFISH   (PHISING)   "
echo $me"17."$e"PHISH Weeman          (PHISING)   "
echo $me"18."$e"INSTALL BAHAN            "
echo $me"19."$e"WEB VULN SCANNER         "
echo $me"20."$e"DEFACE WEBSITE     "
echo $me"21."$e"EXIT/KELUAR  "

echo
read -p"Pilih Angka==> " pil

if [ $pil = 1 ]
then
clear
figlet -f slant "W A I T"|lolcat
sleep 1
git clone https://github.com/cyweb/hammer
cd hammer
python3 hammer.py
fi

if [ $pil = 2 ]
then
clear
figlet -f slant "W A I T"|lolcat
sleep 1
git clone https://github.com/Tuhinshubhra/RED_HAWK
cd RED_HAWK
php rhawk.php
fi

if [ $pil = 3 ]
then
clear
figlet -f slant "W A I T"|lolcat
sleep 1
git clone https://github.com/thelinuxchoice/locator
cd locator
bash locator.sh
fi

if [ $pil = 4 ]
then
clear
figlet -f slant "W A I T"|lolcat
sleep 1
git clone https://github.com/FR13ND8/BRUTEFORCEnew
cd BRUTEFORCEnew
sh new.sh
fi

if [ $pil = 5 ]
then
clear
figlet -f slant "W A I T"|lolcat
sleep 1
git clone https://github.com/sqlmapproject/sqlmap
cd sqlmap
python sqlmap.py
fi

if [ $pil = 6 ]
then
clear
figlet -f slant "W A I T"|lolcat
sleep 1
git clone https://github.com/ory/hydra
cd hydra
./install.sh
fi

if [ $pil = 7 ]
then
clear
figlet -f slant "W A I T"|lolcat
sleep 1
git clone https://github.com/404rgr/webdav77
cd webdav77
chmod +x *
./install.sh
bash webdav77.sh
fi

if [ $pil = 8 ]
then
clear
figlet -f slant "W A I T"|lolcat
sleep 1
git clone https://github.com/FR13ND8/ProfileGuardFb
cd ProfileGuardFb
php guard.php
fi

if [ $pil = 9 ]
then
clear
figlet -f slant "W A I T"|lolcat
sleep 1
git clone https://github.com/IlayTamvan/Report
cd Report
unzip Report.zip
python2 Report.py
fi

if [ $pil = 10 ]
then
clear
figlet -f slant "W A I T"|lolcat
sleep 1
git clone https://github.com/ikiganteng/bot-igeh
cd bot-igeh
chmod 777 node_modules.zip
unzip node_modules.zip
node index.js
fi

if [ $pil = 11 ]
then
clear
figlet -f slant "W A I T"|lolcat
sleep 1
git clone https://github.com/muhammadfathul/VIRTEX
cd VIRTEX
sh virtex.sh
fi

if [ $pil = 12 ]
then
clear
figlet -f slant "W A I T"|lolcat
sleep 1
git clone https://github.com/esc0rtd3w/wifi-hacker
cd wifi-hacker
chmod +x *
sh wifi-hacker.sh
fi

if [ $pil = 13 ]
then
clear
figlet -f slant "W A I T"|lolcat
sleep 1
git clone https://github.com/underxploit/enoxuia
cd enoxuia
php enox.php
fi

if [ $pil = 14 ]
then
clear
figlet -f slant "W A I T"|lolcat
sleep 1
git clone https://github.com/thelinuxchoice/shellphish.git
cd shellphish
bash shellphish.sh
fi

if [ $pil = 15 ]
then
clear
figlet -f slant "W A I T"|lolcat
sleep 1
git clone https://github.com/thelinuxchoice/blackeye.git
cd blackeye
bash blackeye.sh
fi

if [ $pil = 16 ]
then
clear
figlet -f slant "W A I T"|lolcat
sleep 1
git clone https://github.com/UndeadSec/SocialFish.git
cd SocialFish
chmod +x *
pip2 install -r requirements.txt
python2 SocialFish.py
fi

if [ $pil = 17 ]
then
clear
figlet -f slant "W A I T"|lolcat
sleep 1
https://github.com/evait-security/weeman.git
chmod +x *
python2 weeman.py
fi

if [ $pil = 18 ]
then
clear
pkg install unzip
pkg install php
pkg install nodejs
apt update && apt upgrade
apt install python2
pip2 install urllib3 chardet certifi idna requests
pkg install git
pip install requests
pip2 install requests
pip install mechanize
pkg install unstable-repo
pip2 install mechanize
pkg install curl
pkg install openssh
pkg install php
pjg install python
pkg install ruby
pkg install gem
gem install lolcat
pkg install git
pkg install php
pkg install ruby cowsay toilet figlet
pkg install neofetch
pkg install nano
figlet -f slant " S U K S E S "|lolcat
fi

if [ $pil = 19 ]
then
clear
git clone https://github.com/E4rr0r4/XGDork
cd XGDork
python2 XGDork.py
fi

if [ $pil = 20 ]
then
clear
git clone https://github.com/Amriez/AOCDEFACE
cd AOCDEFACE
chmod +x *
./install.sh
clear
sh AOC.sh
fi

if [ $pil = 21 ]
then
clear
figlet -f slant "E X I T"|lolcat
sleep 2
echo $cy"Terima Kasih Sudah Pakai Tool Saya"
sleep 2
echo $i"Bila Ada Kesalahan Kamu Bisa Nanya Kepada Saya"
sleep 2
echo $ku"WhatsApp :"$i" +371 21 366 841"
echo $ku"Facebook :"$i" Mohammad Kelvin"
sleep 2
echo $pur">> Thanks Yang Sudah Support Saya <<"
exit
fi



