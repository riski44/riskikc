[!] Cara Menggunakan [!]
$ apt update
$ apt upgrade
$ apt install git
$ git clone https://github.com/404rgr/webdav77
$ cd webdav77
$ chmod 777 webdav77.sh
$ bash install.sh

#Note
tools ini hanya khusus  web yang vuln webdav
dan juga digunakan untuk membuat script deface

#info
Name Tool : webdav77
Author    : 404rgr | Pausi Channel
Team      : Rao Cyber Team
No Wa     : 0895320325423{jangan di spam yeaa}
Email     : 404rgr@gmail.com
Website   : 404rgr.zone.id

