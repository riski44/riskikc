# XGDork - ViraX Google Dork Scanner

SQLi Google Dork Scanner by ViraX @ 2018 - 2019
- for Python 2.7 - compatible Android(NoRoot) - Termux

A simple 'naive' python tool to find SQLi Vulnerable websites in the wild via Google.

[!] DISCLAIMER: I am not responsible for illegal acts that you would do with this program !, only educational . [!]
  - SQL Dork Scanner
  - SQL Dumper module (basic)
  - Simple Tools

--- Setup ---
- install Python 2.7 / on Termux 'pkg install python2'
- pip/pip2 install requests
- pip/pip2 install termcolor
- install git / on Termux 'pkg install git'
- git clone https://github.com/E4rr0r4/XGDork.git
- cd XGDork
- chmod XGDork.py (optional)
- python/python2 XGDork.py --help


version: Final-1.0k-FreeSoftware

- Contributor(s)/Source(s)
  * SQLmap 'agents file' - https://github.com/sqlmapproject/
