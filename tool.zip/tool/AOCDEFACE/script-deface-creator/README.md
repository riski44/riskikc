# script-deface-creator
Script deface creator by Ubaii ID
