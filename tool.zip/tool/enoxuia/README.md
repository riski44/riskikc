# Enoxuia
Spam Sms &amp; Call (Only for Termux)
<pre>
$ apt update && apt upgrade
$ pkg install php
$ pkg install git
$ git clone https://github.com/underxploit/Enoxuia
$ cd Enoxuia
$ php enox.php
</pre>
