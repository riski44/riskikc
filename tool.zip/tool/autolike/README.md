# autolike
pinjam scriptnya dulu bang Rusmana
